sudo apt-get update
sudo apt-get install python-pip git python-dev -y
sudo pip install -r requirements.txt 
